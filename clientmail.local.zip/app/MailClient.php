<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MailClient extends Model
{
    protected $table = 'mail';
}

